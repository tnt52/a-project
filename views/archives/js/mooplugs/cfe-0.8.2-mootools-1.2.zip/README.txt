README FOR Custom Form Elements
****************************************************

1. About this package
****************************************************


2. What is/are Custom Form Elements?
****************************************************


3. Requirements to use CFE
****************************************************

���javascript frameworks
Custom Form Elements are based on various Javascript Framworks.
Currently mootools 1.1 and mootools 1.2 are supported


4. What should you do if you have a problem?
****************************************************


X. Kudos
****************************************************

CFE would be nothing without the work of other great developers and designers.
I'd like to thank you for giving me the opportunity to realize this project,
as you build the basement for all this!

Kudos to all developers!


Custom Form Elements uses icons from the silk icon set, which are
distrubuted by Mark James on http://www.famfamfam.com/lab/icons/silk/ under the
Creative Commons Attribution 2.5 License [http://creativecommons.org/licenses/by/2.5/]

Great work Mark!! 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
P.S. if you use those icons on your site, you've got to somehow link back to Mark (famfamfam.com)
as his work is licenced under Creative Commons Attribution 2.5 License
